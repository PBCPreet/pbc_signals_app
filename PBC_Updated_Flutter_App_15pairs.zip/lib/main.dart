
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(PBCApp());

class PBCApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PBC - Preet Binary Calls',
      theme: ThemeData.dark(),
      home: SignalScreen(),
    );
  }
}

class SignalScreen extends StatefulWidget {
  @override
  _SignalScreenState createState() => _SignalScreenState();
}

class _SignalScreenState extends State<SignalScreen> {
  String selectedPair = 'EUR/USD';
  String signal = 'Loading...';
  double accuracy = 0.0;
  Timer? countdownTimer;
  int remainingSeconds = 60;
  final pairs = ['EUR/USD', 'GBP/CAD', 'AUD/CHF', 'GBP/AUD', 'USD/JPY', 'EUR/JPY', 'USD/CAD', 'AUD/USD', 'NZD/JPY', 'CHF/JPY', 'EUR/GBP', 'GBP/JPY', 'USD/CHF', 'EUR/AUD', 'CAD/JPY'];
  final timeFrames = ['1m', '2m', '3m', '5m'];
  String selectedTimeFrame = '1m';

  @override
  void initState() {
    super.initState();
    startTimer();
    fetchSignal();
  }

  void startTimer() {
    countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          remainingSeconds--;
          if (remainingSeconds == 5) {
            fetchSignal();
          }
          if (remainingSeconds <= 0) {
            remainingSeconds = 60;
          }
        });
      }
    });
  }

  Future<void> fetchSignal() async {
    try {
      final response = await http.get(Uri.parse(
          'https://api.preetbinarysignals.com/get-signal?pair=$selectedPair&tf=$selectedTimeFrame'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          signal = data['signal'];
          accuracy = data['accuracy'];
        });
      } else {
        setState(() {
          signal = 'Error fetching signal';
          accuracy = 0.0;
        });
      }
    } catch (e) {
      setState(() {
        signal = 'Network error';
        accuracy = 0.0;
      });
    }
  }

  @override
  void dispose() {
    countdownTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Preet Binary Calls (PBC)'),
          bottom: TabBar(
            tabs: [
              Tab(icon: Icon(Icons.signal_cellular_alt), text: 'Signals'),
              Tab(icon: Icon(Icons.show_chart), text: 'Chart'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            buildSignalTab(),
            buildChartTab(),
          ],
        ),
      ),
    );
  }

  Widget buildSignalTab() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        DropdownButton<String>(
          value: selectedPair,
          onChanged: (newValue) {
            setState(() {
              selectedPair = newValue!;
              fetchSignal();
            });
          },
          items: pairs.map<DropdownMenuItem<String>>((String pair) {
            return DropdownMenuItem<String>(
              value: pair,
              child: Text(pair),
            );
          }).toList(),
        ),
        DropdownButton<String>(
          value: selectedTimeFrame,
          onChanged: (newValue) {
            setState(() {
              selectedTimeFrame = newValue!;
              fetchSignal();
            });
          },
          items: timeFrames.map<DropdownMenuItem<String>>((String tf) {
            return DropdownMenuItem<String>(
              value: tf,
              child: Text('TF: $tf'),
            );
          }).toList(),
        ),
        SizedBox(height: 20),
        Text(
          'Signal: $signal',
          style: TextStyle(fontSize: 24, color: signal == 'CALL' ? Colors.green : Colors.red),
        ),
        SizedBox(height: 10),
        Text('Accuracy: ${accuracy.toStringAsFixed(1)}%'),
        SizedBox(height: 10),
        Text('Next candle in: $remainingSeconds sec'),
      ],
    );
  }

  Widget buildChartTab() {
    return WebView(
      initialUrl: 'https://www.tradingview.com/chart/',
      javascriptMode: JavascriptMode.unrestricted,
    );
  }
}
